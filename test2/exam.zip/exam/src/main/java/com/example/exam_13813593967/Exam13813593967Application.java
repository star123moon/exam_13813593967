package com.example.exam_13813593967;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Exam13813593967Application {

	public static void main(String[] args) {
		SpringApplication.run(Exam13813593967Application.class, args);
	}

}
