package com.example.exam_13813593967.exam1.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.util.Date;

@Data
@TableName("test1_crime")
public class Crime {

    @TableId(type = IdType.AUTO)
    private Integer incident_id;

    private String offence_code;

    private Date dispatch_time;

    private String victims;

    private String crime_name1;

    private String crime_name2;

    private String crime_name3;

    private String city;

    private Date start_date_time;

}
