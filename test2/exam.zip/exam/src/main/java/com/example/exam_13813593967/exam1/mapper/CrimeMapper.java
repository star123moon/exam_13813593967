package com.example.exam_13813593967.exam1.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.exam_13813593967.exam1.model.Crime;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CrimeMapper extends BaseMapper<Crime> {
}
