package com.example.exam_13813593967.exam1.controller;

import com.example.exam_13813593967.exam1.mapper.CrimeMapper;
import com.example.exam_13813593967.exam1.model.Crime;

import com.example.exam_13813593967.exam1.model.SwaggerReqVo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Api(value = "犯罪接口",tags = "犯罪接口")
@RestController
@RequestMapping("/api/crime")
public class crimeController {

    @Autowired
    private JdbcTemplate jdbcTemplate;
    @Autowired
    private CrimeMapper crimeMapper;


    @ApiIgnore
    @ApiOperation("批量删除id重复数据")
    @PostMapping("/handledata")
    public void handledata(){
        String sql = " select  a.incident_id from ( " +
                " SELECT incident_id,count(1) co FROM `test1_crime` GROUP BY incident_id HAVING count(1) >1)a ";

        //获取重复id的id值
        List<Map<String, Object>> incidentidList = jdbcTemplate.queryForList(sql);

        for (Map<String, Object> stringObjectMap : incidentidList) {
            String incidentid = stringObjectMap.get("incident_id").toString();
            String sql1 = " DELETE  from test1_crime where (incident_id, offence_code,start_date_time) in (" +
                    " select a.incident_id, a.offence_code,a.start_date_time from ( " +
                    " select incident_id, offence_code,start_date_time from test1_crime where  incident_id = '"+incidentid+"' and (incident_id, offence_code,start_date_time) not in " +
                    " (select incident_id,MAX(offence_code),MAX(start_date_time)  from test1_crime where incident_id = '"+incidentid+"' order by start_date_time,offence_code desc))a " +
                    " ) ";
            jdbcTemplate.update(sql1);

        }
    }


    @ApiOperation("城市风险指数统计接口")
    @GetMapping("/stat")
    public Map<String,Object> stat(){
        List<Map<String,Object>> crimeAll = new ArrayList<>();

        //获取年份
        String getEveryYearSql = "select DATE_FORMAT(start_date_time,'%Y') year from test1_crime GROUP BY DATE_FORMAT(start_date_time,'%Y') " +
                " order by DATE_FORMAT(start_date_time,'%Y') asc";
        List<Map<String,Object>> yearList = jdbcTemplate.queryForList(getEveryYearSql);
        //循环年份List获取每年的数据
        for (Map<String, Object> yearMap : yearList) {
            HashMap<String, Object> everyYearcrimeMap = new HashMap<>();
            String year = yearMap.get("year").toString();
            String numSql = "select city,a.ajs,a.shrs from( " +
                    " select city,count(1) ajs,sum(victims) shrs from test1_crime where start_date_time like '"+year+"%' group by city \n" +
                    " )a order by a.ajs desc,a.shrs desc ";
            List<Map<String,Object>> crimeNumList = jdbcTemplate.queryForList(numSql);
            //获取犯罪数量和受害人数前三的城市和数据
            List<Map<String,Object>> riskTop3List = new ArrayList<>();
            for (int i = 0; i < 3; i++) {
                Map<String, Object> cityInfo = new HashMap<>();
                String cityName = crimeNumList.get(i).get("city").toString();
                Double ajs = Double.valueOf(crimeNumList.get(i).get("ajs").toString());
                Double shrs = Double.valueOf(crimeNumList.get(i).get("shrs").toString());
                Double riskIndex = (ajs/365)*0.8+(shrs/365)*0.2;

                //获取前三罪名
                String getCrimeNameSql = "select crime_name3 ,count(*) from test1_crime where start_date_time like '"+year+"%' " +
                        "and city = '"+cityName+"' " +
                        " group by crime_name3  ORDER BY count(1) desc";
                List<Map<String,Object>> crimeNameList = jdbcTemplate.queryForList(getCrimeNameSql);
                List<String> crimeStrList = new ArrayList<>();
                crimeStrList.add(crimeNameList.get(0).get("crime_name3").toString());
                crimeStrList.add(crimeNameList.get(1).get("crime_name3").toString());
                crimeStrList.add(crimeNameList.get(2).get("crime_name3").toString());

                cityInfo.put("city",cityName);
                cityInfo.put("riskIndex",String.format("%.2f", riskIndex));
                cityInfo.put("rank",i+1);
                cityInfo.put("crimeTop3",crimeStrList);

                riskTop3List.add(cityInfo);
            }

            everyYearcrimeMap.put("year",year);
            everyYearcrimeMap.put("riskTop3",riskTop3List);

            crimeAll.add(everyYearcrimeMap);
        }

        Map<String, Object> endMap = new HashMap<>();
        endMap.put("code",0);
        endMap.put("message","ok");
        endMap.put("result",crimeAll);

        return endMap;
    }

    @ApiOperation("新增犯罪记录接口")
    @PostMapping
    public Map<String,Object> add(@RequestBody SwaggerReqVo swaggerReqVo){
        Map<String, Object> hashMap = new HashMap<>();
        Crime crime = new Crime();
        crime.setCity(swaggerReqVo.getCity());
        crime.setVictims(swaggerReqVo.getVictims());
        crime.setOffence_code(swaggerReqVo.getOffenceCode());
        crime.setStart_date_time(swaggerReqVo.getStartDateTime());
        crime.setDispatch_time(swaggerReqVo.getDispatchTime());

        try {
            int insert = crimeMapper.insert(crime);

            hashMap.put("code","0");
            hashMap.put("message","插入成功");
            if (insert != 1){
                hashMap.put("code","1");
                hashMap.put("message","插入失败");
            }

        }catch (Exception e){
            hashMap.put("code","1");
            hashMap.put("message","插入失败");
        }
        return hashMap;

    }


}
