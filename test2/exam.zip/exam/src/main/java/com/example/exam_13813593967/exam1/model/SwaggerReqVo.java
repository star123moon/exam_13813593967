package com.example.exam_13813593967.exam1.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import jdk.nashorn.internal.runtime.JSONFunctions;
import lombok.Data;

import java.util.Date;

@Data
@ApiModel("创建Swagger请求参数")
public class SwaggerReqVo {
    private String city;
    private String Victims;
    private String offenceCode;
    private Date startDateTime;
    private Date dispatchTime;


}
