package com.example.exam_13813593967.exam1.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel("创建Swagger响应结果")
public class SwaggerResVo {

    @ApiModelProperty("状态")
    private Integer code;

    @ApiModelProperty("信息")
    private String message;



}
