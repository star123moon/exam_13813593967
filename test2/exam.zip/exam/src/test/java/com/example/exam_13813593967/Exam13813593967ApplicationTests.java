package com.example.exam_13813593967;


import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Exam13813593967ApplicationTests {



}
